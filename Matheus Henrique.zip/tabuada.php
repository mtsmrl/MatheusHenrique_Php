<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
  for($i = 0; $i < 10; $i++) {
        print " $i x 1 = " . $i * 1 . "<br>";
        print " $i x 2 =  " . $i * 2 . "<br>";
        print " $i x 3 =  " . $i * 3 . "<br>";
        print " $i x 4 =  " . $i * 4 . "<br>";
        print " $i x 5 = " . $i * 5 . "<br>";
        print " $i x 6 =  " . $i * 6 . "<br>";
        print " $i x 7 =  " . $i * 7 . "<br>";
        print " $i x 8 =  " . $i * 8 . "<br>";
        print " $i x 9 =  " . $i * 9 . "<br>";
        print " $i x 10 =  " . $i * 10 . "<br><br>";
  }
    ?>
    <adress>
        <center>
            Matheus Henrique Coelho Amaral
        </center>
    </adress>

</body>
</html>